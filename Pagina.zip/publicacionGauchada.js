$(document).ready(function(){
// When the <input>'s value changes
	$.validator.setDefaults({
    errorElement: "span",
    errorClass: "help-block",
    highlight: function (element, errorClass, validClass) {
        $(element).closest('.form-group').addClass('has-error');
    },
    unhighlight: function (element, errorClass, validClass) {
        $(element).closest('.form-group').removeClass('has-error');
    },
    errorPlacement: function (error, element) {
        if (element.parent('.input-group').length || element.prop('type') === 'checkbox' || element.prop('type') === 'radio') {
            error.insertAfter(element.parent());
        } else {
            error.insertAfter(element);
        }
    }
	});
	
	$("#publicacionForm").validate({
		rules: {
			titulo: "required",
			fechaVencimiento: "required",
			ciudad: "required",
			categoria: { required: true},
			descripcion: "required",
		},
		messages: {
			titulo: "Campo obligatorio",
			fechaVencimiento: "Campo obligatorio",
			ciudad: "Campo obligatorio",
			categoria: "Campo obligatorio",
			descripcion:"Campo obligatorio"
		}
	});
	$("#publicar").click(function(){
		$("#publicacionForm").valid();
	});
	$("#imagenSubida").change(function() {
		readURL(this);
	});

});

function readURL(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();
		
		reader.onload = function (e) {
			$('#imagenGauchada').attr('src', e.target.result);
		}
		
		reader.readAsDataURL(input.files[0]);
	}
}